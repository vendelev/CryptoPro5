#include "fat12prj.h"
#include "reader.kit/rdr_ver.h"
#ifdef __cplusplus
extern "C" {
#endif //__cplusplus

    DWORD flash_group_enum_open(TSupSysContext *context, TSupSysInfo *info);
    DWORD flash_group_enum_next(TSupSysContext *context, TSupSysInfo *info);
    DWORD flash_group_enum_close(TSupSysContext *context, TSupSysInfo *info);
    DWORD flash_group_info_system_flag(TSupSysContext *context, TSupSysInfo *info);

#ifdef __cplusplus
    }
#endif //__cplusplus
