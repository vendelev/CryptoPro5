//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by hvisdefrc.rc
//
#define IDD_DIALOG_ASK                  400
#define IDD_DIALOG_ASK_SMALL            401
#define IDC_ASK_FIELD                   1027
#define IDC_COMBO1                      1029
#define IDC_STATIC_FRAME_HEADER         1030
#define IDC_STATIC_TIME                 1119
#define IDC_STATIC_TIME2                1120

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        112
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1031
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
