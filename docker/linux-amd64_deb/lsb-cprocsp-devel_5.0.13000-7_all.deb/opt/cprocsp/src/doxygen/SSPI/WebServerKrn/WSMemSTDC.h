#ifndef _WSMEM_STDC_H_
#define _WSMEM_STDC_H_
#include"wincspc.h"
#ifdef __cplusplus
extern "C" {
#endif
extern DWORD CPCAPI stdInitMemory(LPCPC_MEMORY_ARENA *pArena, LONG *PoolSizes, DWORD nPools);
extern void mark_alloced();
extern void check_alloced();
#ifdef __cplusplus
}
#endif
#endif
