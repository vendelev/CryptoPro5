#ifndef _IKEV2G_LIC_H_
#define _IKEV2G_LIC_H_

#include "types.h"

bool is_lic_prov(HCRYPTPROV hProv, bool *is_export);

#endif //_IKEV2G_LIC_H_
